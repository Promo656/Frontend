describe('homework 3', () => {

});