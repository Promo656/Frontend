import * as lesson3 from './lesson3';
