console.log('Lesson 3');

//////////////////////
// Можно ли изменить объект, объявленный с помощью const?

////////////////
// Дано:

// const bird = {
//   size: 'small',
// };

// const mouse = {
//   name: 'Mickey',
//   small: true,
// };

// Что вернут вызовы:
// А) mouse.bird.size
// Б) mouse[bird.size]
// В) mouse[bird["size"]]

///////////////////////
// Что выведет консоль:
// let c = { greeting: 'Hey!' };
// let d;
// d = c;
// c.greeting = 'Hello';
// console.log(d.greeting);


//////////////
// Что выведет консоль:
// const obj = { a: 'one', b: 'two', a: 'three' };
// console.log(obj);
